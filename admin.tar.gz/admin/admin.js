/* ===================================================================
   OSC-MUST Admin Panel — admin.js
   Works with admin/server.py — saves files locally + git push.
   No OAuth, no tokens. Uses YOUR git config (SSH / HTTPS).
   =================================================================== */

(function () {
  'use strict';

  var state = {
    gitUser: { name: '', email: '', remote: '' },
    pendingChanges: {},   // { filepath: { content, action } }
    siteData: {
      about: { paragraphs: [], tags: [] },
      blog: [],
      events: [],
      team: [],
      join: { text: '', links: [] }
    }
  };

  function $(id) { return document.getElementById(id); }
  function show(el) { el.classList.remove('hidden'); }
  function hide(el) { el.classList.add('hidden'); }

  function el(tag, attrs, children) {
    var node = document.createElement(tag);
    if (attrs) Object.keys(attrs).forEach(function (k) {
      if (k === 'className') node.className = attrs[k];
      else if (k.indexOf('on') === 0) node.addEventListener(k.slice(2).toLowerCase(), attrs[k]);
      else if (k === 'value') node.value = attrs[k];
      else node.setAttribute(k, attrs[k]);
    });
    if (children) {
      if (typeof children === 'string') node.textContent = children;
      else if (Array.isArray(children)) children.forEach(function (c) { if (c) node.appendChild(c); });
      else node.appendChild(children);
    }
    return node;
  }

  function api(method, path, body) {
    var opts = { method: method, headers: { 'Content-Type': 'application/json' } };
    if (body) opts.body = JSON.stringify(body);
    return fetch(path, opts).then(function (r) { return r.json(); });
  }

  function parseHTML(html) {
    return new DOMParser().parseFromString(html, 'text/html');
  }

  function loadSiteData() {
    log('Fetching site data from local files...');
    return Promise.all([
      api('GET', '/api/file/about.html'),
      api('GET', '/api/file/blog.html'),
      api('GET', '/api/file/events.html'),
      api('GET', '/api/file/team.html'),
      api('GET', '/api/file/join.html')
    ]).then(function (results) {
      // Parse About
      if (results[0] && results[0].content) {
        var aboutDoc = parseHTML(results[0].content);
        var paras = aboutDoc.querySelectorAll('.manifesto p');
        state.siteData.about.paragraphs = [];
        paras.forEach(function (p) { state.siteData.about.paragraphs.push(p.textContent.trim()); });
        var tags = aboutDoc.querySelectorAll('.tag');
        state.siteData.about.tags = [];
        tags.forEach(function (t) { state.siteData.about.tags.push(t.textContent.trim()); });
      }

      // Parse Blog
      if (results[1] && results[1].content) {
        var blogDoc = parseHTML(results[1].content);
        var rows = blogDoc.querySelectorAll('.terminal-table tbody tr');
        state.siteData.blog = [];
        rows.forEach(function (row) {
          var cells = row.querySelectorAll('td');
          if (cells.length >= 4) {
            var link = cells[2].querySelector('a');
            var href = link ? link.getAttribute('href') : '';
            var fname = href.replace('blog/', '').replace('.html', '');
            state.siteData.blog.push({
              perms: cells[0].textContent.trim(),
              date: cells[1].textContent.trim(),
              filename: fname,
              title: cells[3].textContent.trim(),
              content: ''
            });
          }
        });
      }

      // Parse Events
      if (results[2] && results[2].content) {
        var evDoc = parseHTML(results[2].content);
        var evRows = evDoc.querySelectorAll('.terminal-table tbody tr');
        state.siteData.events = [];
        evRows.forEach(function (row) {
          var cells = row.querySelectorAll('td');
          if (cells.length >= 5) {
            var link = cells[3].querySelector('a');
            var href = link ? link.getAttribute('href') : '';
            var fname = href.replace('events/', '').replace('.html', '');
            state.siteData.events.push({
              perms: cells[0].textContent.trim(),
              type: cells[1].textContent.trim(),
              date: cells[2].textContent.trim(),
              filename: fname,
              title: cells[4].textContent.trim(),
              content: '',
              location: ''
            });
          }
        });
      }

      // Parse Team
      if (results[3] && results[3].content) {
        var teamDoc = parseHTML(results[3].content);
        var teamRows = teamDoc.querySelectorAll('.terminal-table tbody tr');
        state.siteData.team = [];
        teamRows.forEach(function (row) {
          var cells = row.querySelectorAll('td');
          if (cells.length >= 3) {
            var ghLink = cells[2].querySelector('a');
            state.siteData.team.push({
              handle: cells[0].textContent.trim(),
              role: cells[1].textContent.trim(),
              github: ghLink ? ghLink.textContent.trim() : ''
            });
          }
        });
      }

      // Parse Join
      if (results[4] && results[4].content) {
        var joinDoc = parseHTML(results[4].content);
        var joinText = joinDoc.querySelector('main p[style]');
        state.siteData.join.text = joinText ? joinText.textContent.trim() : '';
        var joinLinks = joinDoc.querySelectorAll('.link-row');
        state.siteData.join.links = [];
        joinLinks.forEach(function (a) {
          var tag = a.querySelector('.tag');
          var url = a.querySelector('.url');
          state.siteData.join.links.push({
            label: tag ? tag.textContent.replace(/[\[\]\s\u00a0]/g, '') : '',
            url: url ? url.textContent.trim() : a.getAttribute('href')
          });
        });
      }

      log('Site data loaded.', 'success');
      renderAll();
    }).catch(function (err) {
      log('Error loading site data: ' + err.message, 'error');
    });
  }


  function generateBlogListHTML() {
    var rows = '';
    state.siteData.blog.forEach(function (b) {
      rows += '              <tr>\n' +
        '                <td class="c-muted">' + escHtml(b.perms) + '</td>\n' +
        '                <td class="c-muted">' + escHtml(b.date) + '</td>\n' +
        '                <td><a href="blog/' + escHtml(b.filename) + '.html" class="c-primary">' + escHtml(b.filename) + '.md</a></td>\n' +
        '                <td class="c-fg">' + escHtml(b.title) + '</td>\n' +
        '              </tr>\n';
    });
    return '<!DOCTYPE html>\n' +
      '<html lang="en" dir="ltr">\n' +
      '<head>\n' +
      '  <meta charset="UTF-8" />\n' +
      '  <meta name="viewport" content="width=device-width, initial-scale=1.0" />\n' +
      '  <link rel="icon" type="image/png" href="assets/OSC_logo-psd.png" />\n' +
      '  <title>Blog — OSC-MUST</title>\n' +
      '  <link rel="preconnect" href="https://fonts.googleapis.com" />\n' +
      '  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />\n' +
      '  <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet" />\n' +
      '  <link rel="stylesheet" href="style.css" />\n' +
      '</head>\n' +
      '<body>\n' +
      '  <div class="site-wrapper">\n\n' +
      '    <nav class="nav">\n' +
      '      <div class="nav-inner">\n' +
      '        <div class="nav-left">\n' +
      '          <a href="index.html" class="nav-prompt">\n' +
      '            <span class="bracket">[</span>user@osc-must ~<span class="bracket">]$</span>\n' +
      '          </a>\n' +
      '          <div class="nav-links">\n' +
      '            <a href="about.html"  class="nav-link">./about</a>\n' +
      '            <a href="blog.html"   class="nav-link active">./blog</a>\n' +
      '            <a href="events.html" class="nav-link">./events</a>\n' +
      '            <a href="team.html"   class="nav-link">./team</a>\n' +
      '            <a href="join.html"   class="nav-link">./join</a>\n' +
      '          </div>\n' +
      '        </div>\n' +
      '      </div>\n' +
      '    </nav>\n\n' +
      '    <main>\n' +
      '      <div class="container py-12" id="scroll-root">\n' +
      '        <p class="page-header">[user@osc-must ~]$ ls -la ./blog/</p>\n\n' +
      '        <div class="reveal table-wrap">\n' +
      '          <table class="terminal-table">\n' +
      '            <thead>\n' +
      '              <tr>\n' +
      '                <th>perms</th>\n' +
      '                <th>date</th>\n' +
      '                <th>filename</th>\n' +
      '                <th>title</th>\n' +
      '              </tr>\n' +
      '            </thead>\n' +
      '            <tbody>\n' +
      rows +
      '            </tbody>\n' +
      '          </table>\n' +
      '        </div>\n' +
      '      </div>\n' +
      '    </main>\n\n' +
      '    <footer class="footer">\n' +
      '      <div class="footer-inner">\n' +
      '        <span>/home/OSC-MUST</span>\n' +
      '        <span>Misr University for Science and Technology</span>\n' +
      '      </div>\n' +
      '    </footer>\n\n' +
      '  </div>\n' +
      '  <script src="app.js"><\/script>\n' +
      '</body>\n' +
      '</html>\n' +
      '<!-- Written by ELBULBOL -->\n';
  }

  function generateBlogPostHTML(post) {
    var paragraphs = post.content.split(/\n\s*\n/).filter(Boolean);
    var body = paragraphs.map(function (p) {
      return '          <p>' + escHtml(p.trim()) + '</p>';
    }).join('\n');

    return '<!DOCTYPE html>\n' +
      '<html lang="en" dir="ltr">\n' +
      '<head>\n' +
      '  <meta charset="UTF-8" />\n' +
      '  <meta name="viewport" content="width=device-width, initial-scale=1.0" />\n' +
      '  <link rel="icon" type="image/png" href="../assets/OSC_logo-psd.png" />\n' +
      '  <title>' + escHtml(post.title) + ' — OSC-MUST</title>\n' +
      '  <link rel="preconnect" href="https://fonts.googleapis.com" />\n' +
      '  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />\n' +
      '  <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet" />\n' +
      '  <link rel="stylesheet" href="../style.css" />\n' +
      '</head>\n' +
      '<body>\n' +
      '  <div class="site-wrapper">\n\n' +
      '    <nav class="nav">\n' +
      '      <div class="nav-inner">\n' +
      '        <div class="nav-left">\n' +
      '          <a href="../index.html" class="nav-prompt">\n' +
      '            <span class="bracket">[</span>user@osc-must ~<span class="bracket">]$</span>\n' +
      '          </a>\n' +
      '          <div class="nav-links">\n' +
      '            <a href="../about.html"  class="nav-link">./about</a>\n' +
      '            <a href="../blog.html"   class="nav-link active">./blog</a>\n' +
      '            <a href="../events.html" class="nav-link">./events</a>\n' +
      '            <a href="../team.html"   class="nav-link">./team</a>\n' +
      '            <a href="../join.html"   class="nav-link">./join</a>\n' +
      '          </div>\n' +
      '        </div>\n' +
      '      </div>\n' +
      '    </nav>\n\n' +
      '    <main>\n' +
      '      <div class="container-narrow py-12">\n' +
      '        <p class="page-header">[user@osc-must ~]$ cat blog/' + escHtml(post.filename) + '.md</p>\n\n' +
      '        <h1 class="post-title">' + escHtml(post.title) + '</h1>\n\n' +
      '        <div class="post-meta">\n' +
      '          <span>' + escHtml(post.date) + '</span>\n' +
      '          <span>OSC-MUST</span>\n' +
      '        </div>\n\n' +
      '        <article class="post-body">\n' +
      body + '\n' +
      '        </article>\n\n' +
      '        <a href="../blog.html" class="back-link">← cd ../blog</a>\n' +
      '      </div>\n' +
      '    </main>\n\n' +
      '    <footer class="footer">\n' +
      '      <div class="footer-inner">\n' +
      '        <span>/home/OSC-MUST</span>\n' +
      '        <span>Misr University for Science and Technology</span>\n' +
      '      </div>\n' +
      '    </footer>\n\n' +
      '  </div>\n' +
      '  <script src="../app.js"><\/script>\n' +
      '</body>\n' +
      '</html>\n' +
      '<!-- Written by ELBULBOL -->\n';
  }

  function generateEventsListHTML() {
    var rows = '';
    state.siteData.events.forEach(function (ev) {
      rows += '              <tr>\n' +
        '                <td class="c-muted">' + escHtml(ev.perms) + '</td>\n' +
        '                <td class="c-accent">' + escHtml(ev.type) + '</td>\n' +
        '                <td class="c-muted">' + escHtml(ev.date) + '</td>\n' +
        '                <td><a href="events/' + escHtml(ev.filename) + '.html" class="c-primary">' + escHtml(ev.filename) + '</a></td>\n' +
        '                <td class="c-fg">' + escHtml(ev.title) + '</td>\n' +
        '              </tr>\n';
    });
    return '<!DOCTYPE html>\n' +
      '<html lang="en" dir="ltr">\n' +
      '<head>\n' +
      '  <meta charset="UTF-8" />\n' +
      '  <meta name="viewport" content="width=device-width, initial-scale=1.0" />\n' +
      '  <link rel="icon" type="image/png" href="assets/OSC_logo-psd.png" />\n' +
      '  <title>Events — OSC-MUST</title>\n' +
      '  <link rel="preconnect" href="https://fonts.googleapis.com" />\n' +
      '  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />\n' +
      '  <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet" />\n' +
      '  <link rel="stylesheet" href="style.css" />\n' +
      '</head>\n' +
      '<body>\n' +
      '  <div class="site-wrapper">\n\n' +
      '    <nav class="nav">\n' +
      '      <div class="nav-inner">\n' +
      '        <div class="nav-left">\n' +
      '          <a href="index.html" class="nav-prompt">\n' +
      '            <span class="bracket">[</span>user@osc-must ~<span class="bracket">]$</span>\n' +
      '          </a>\n' +
      '          <div class="nav-links">\n' +
      '            <a href="about.html"  class="nav-link">./about</a>\n' +
      '            <a href="blog.html"   class="nav-link">./blog</a>\n' +
      '            <a href="events.html" class="nav-link active">./events</a>\n' +
      '            <a href="team.html"   class="nav-link">./team</a>\n' +
      '            <a href="join.html"   class="nav-link">./join</a>\n' +
      '          </div>\n' +
      '        </div>\n' +
      '      </div>\n' +
      '    </nav>\n\n' +
      '    <main>\n' +
      '      <div class="container py-12" id="scroll-root">\n' +
      '        <p class="page-header">[user@osc-must ~]$ ls -la ./events/</p>\n\n' +
      '        <div class="reveal table-wrap">\n' +
      '          <table class="terminal-table">\n' +
      '            <thead>\n' +
      '              <tr>\n' +
      '                <th>perms</th>\n' +
      '                <th>type</th>\n' +
      '                <th>date</th>\n' +
      '                <th>filename</th>\n' +
      '                <th>description</th>\n' +
      '              </tr>\n' +
      '            </thead>\n' +
      '            <tbody>\n' +
      rows +
      '            </tbody>\n' +
      '          </table>\n' +
      '        </div>\n' +
      '      </div>\n' +
      '    </main>\n\n' +
      '    <footer class="footer">\n' +
      '      <div class="footer-inner">\n' +
      '        <span>/home/OSC-MUST</span>\n' +
      '        <span>Misr University for Science and Technology</span>\n' +
      '      </div>\n' +
      '    </footer>\n\n' +
      '  </div>\n' +
      '  <script src="app.js"><\/script>\n' +
      '</body>\n' +
      '</html>\n' +
      '<!-- Written by ELBULBOL -->\n';
  }

  function generateEventPageHTML(ev) {
    var paragraphs = ev.content.split(/\n\s*\n/).filter(Boolean);
    var body = paragraphs.map(function (p) {
      return '          <p>' + escHtml(p.trim()) + '</p>';
    }).join('\n');

    var metaSpans = '          <span>' + escHtml(ev.date) + '</span>\n' +
      '          <span class="badge">' + escHtml(ev.type) + '</span>';
    if (ev.location) {
      metaSpans += '\n          <span>' + escHtml(ev.location) + '</span>';
    }

    return '<!DOCTYPE html>\n' +
      '<html lang="en" dir="ltr">\n' +
      '<head>\n' +
      '  <meta charset="UTF-8" />\n' +
      '  <meta name="viewport" content="width=device-width, initial-scale=1.0" />\n' +
      '  <link rel="icon" type="image/png" href="../assets/OSC_logo-psd.png" />\n' +
      '  <title>' + escHtml(ev.title) + ' — OSC-MUST</title>\n' +
      '  <link rel="preconnect" href="https://fonts.googleapis.com" />\n' +
      '  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />\n' +
      '  <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet" />\n' +
      '  <link rel="stylesheet" href="../style.css" />\n' +
      '</head>\n' +
      '<body>\n' +
      '  <div class="site-wrapper">\n\n' +
      '    <nav class="nav">\n' +
      '      <div class="nav-inner">\n' +
      '        <div class="nav-left">\n' +
      '          <a href="../index.html" class="nav-prompt">\n' +
      '            <span class="bracket">[</span>user@osc-must ~<span class="bracket">]$</span>\n' +
      '          </a>\n' +
      '          <div class="nav-links">\n' +
      '            <a href="../about.html"  class="nav-link">./about</a>\n' +
      '            <a href="../blog.html"   class="nav-link">./blog</a>\n' +
      '            <a href="../events.html" class="nav-link active">./events</a>\n' +
      '            <a href="../team.html"   class="nav-link">./team</a>\n' +
      '            <a href="../join.html"   class="nav-link">./join</a>\n' +
      '          </div>\n' +
      '        </div>\n' +
      '      </div>\n' +
      '    </nav>\n\n' +
      '    <main>\n' +
      '      <div class="container-narrow py-12">\n' +
      '        <p class="page-header">[user@osc-must ~]$ cat events/' + escHtml(ev.filename) + '</p>\n\n' +
      '        <h1 class="post-title">' + escHtml(ev.title) + '</h1>\n\n' +
      '        <div class="post-meta">\n' +
      metaSpans + '\n' +
      '        </div>\n\n' +
      '        <article class="post-body">\n' +
      body + '\n' +
      '        </article>\n\n' +
      '        <a href="../events.html" class="back-link">← cd ../events</a>\n' +
      '      </div>\n' +
      '    </main>\n\n' +
      '    <footer class="footer">\n' +
      '      <div class="footer-inner">\n' +
      '        <span>/home/OSC-MUST</span>\n' +
      '        <span>Misr University for Science and Technology</span>\n' +
      '      </div>\n' +
      '    </footer>\n\n' +
      '  </div>\n' +
      '  <script src="../app.js"><\/script>\n' +
      '</body>\n' +
      '</html>\n' +
      '<!-- Written by ELBULBOL -->\n';
  }

  function generateAboutHTML() {
    var paras = state.siteData.about.paragraphs.map(function (p) {
      return '          <p>' + escHtml(p) + '</p>';
    }).join('\n');
    var tags = state.siteData.about.tags.map(function (t) {
      return '          <span class="tag">' + escHtml(t) + '</span>';
    }).join('\n');

    return '<!DOCTYPE html>\n' +
      '<html lang="en" dir="ltr">\n' +
      '<head>\n' +
      '  <meta charset="UTF-8" />\n' +
      '  <meta name="viewport" content="width=device-width, initial-scale=1.0" />\n' +
      '  <link rel="icon" type="image/png" href="assets/OSC_logo-psd.png" />\n' +
      '  <title>About — OSC-MUST</title>\n' +
      '  <link rel="preconnect" href="https://fonts.googleapis.com" />\n' +
      '  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />\n' +
      '  <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet" />\n' +
      '  <link rel="stylesheet" href="style.css" />\n' +
      '</head>\n' +
      '<body>\n' +
      '  <div class="site-wrapper">\n\n' +
      '    <nav class="nav">\n' +
      '      <div class="nav-inner">\n' +
      '        <div class="nav-left">\n' +
      '          <a href="index.html" class="nav-prompt">\n' +
      '            <span class="bracket">[</span>user@osc-must ~<span class="bracket">]$</span>\n' +
      '          </a>\n' +
      '          <div class="nav-links">\n' +
      '            <a href="about.html"  class="nav-link active">./about</a>\n' +
      '            <a href="blog.html"   class="nav-link">./blog</a>\n' +
      '            <a href="events.html" class="nav-link">./events</a>\n' +
      '            <a href="team.html"   class="nav-link">./team</a>\n' +
      '            <a href="join.html"   class="nav-link">./join</a>\n' +
      '          </div>\n' +
      '        </div>\n' +
      '      </div>\n' +
      '    </nav>\n\n' +
      '    <main>\n' +
      '      <div class="container-narrow py-12" id="scroll-root">\n' +
      '        <p class="page-header">[user@osc-must ~]$ cat about.txt</p>\n\n' +
      '        <div class="reveal manifesto">\n' +
      paras + '\n' +
      '        </div>\n\n' +
      '        <div class="reveal tag-list">\n' +
      tags + '\n' +
      '        </div>\n' +
      '      </div>\n' +
      '    </main>\n\n' +
      '    <footer class="footer">\n' +
      '      <div class="footer-inner">\n' +
      '        <span>/home/OSC-MUST</span>\n' +
      '        <span>Misr University for Science and Technology</span>\n' +
      '      </div>\n' +
      '    </footer>\n\n' +
      '  </div>\n' +
      '  <script src="app.js"><\/script>\n' +
      '</body>\n' +
      '</html>\n' +
      '<!-- Written by ELBULBOL -->\n';
  }

  function generateTeamHTML() {
    var rows = '';
    state.siteData.team.forEach(function (m) {
      var ghCell;
      if (m.github) {
        ghCell = '<a href="https://github.com/' + escHtml(m.github) + '" target="_blank" rel="noopener noreferrer" class="c-primary">' + escHtml(m.github) + '</a>';
      } else {
        ghCell = '<span class="c-muted">—</span>';
      }
      rows += '              <tr>\n' +
        '                <td class="c-primary">' + escHtml(m.handle) + '</td>\n' +
        '                <td class="c-fg">' + escHtml(m.role) + '</td>\n' +
        '                <td>' + ghCell + '</td>\n' +
        '              </tr>\n';
    });

    return '<!DOCTYPE html>\n' +
      '<html lang="en" dir="ltr">\n' +
      '<head>\n' +
      '  <meta charset="UTF-8" />\n' +
      '  <meta name="viewport" content="width=device-width, initial-scale=1.0" />\n' +
      '  <link rel="icon" type="image/png" href="assets/OSC_logo-psd.png" />\n' +
      '  <title>Team — OSC-MUST</title>\n' +
      '  <link rel="preconnect" href="https://fonts.googleapis.com" />\n' +
      '  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />\n' +
      '  <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet" />\n' +
      '  <link rel="stylesheet" href="style.css" />\n' +
      '</head>\n' +
      '<body>\n' +
      '  <div class="site-wrapper">\n\n' +
      '    <nav class="nav">\n' +
      '      <div class="nav-inner">\n' +
      '        <div class="nav-left">\n' +
      '          <a href="index.html" class="nav-prompt">\n' +
      '            <span class="bracket">[</span>user@osc-must ~<span class="bracket">]$</span>\n' +
      '          </a>\n' +
      '          <div class="nav-links">\n' +
      '            <a href="about.html"  class="nav-link">./about</a>\n' +
      '            <a href="blog.html"   class="nav-link">./blog</a>\n' +
      '            <a href="events.html" class="nav-link">./events</a>\n' +
      '            <a href="team.html"   class="nav-link active">./team</a>\n' +
      '            <a href="join.html"   class="nav-link">./join</a>\n' +
      '          </div>\n' +
      '        </div>\n' +
      '      </div>\n' +
      '    </nav>\n\n' +
      '    <main>\n' +
      '      <div class="container py-12" id="scroll-root">\n' +
      '        <p class="page-header">[user@osc-must ~]$ who -a</p>\n\n' +
      '        <div class="reveal table-wrap">\n' +
      '          <table class="terminal-table">\n' +
      '            <thead>\n' +
      '              <tr>\n' +
      '                <th>handle</th>\n' +
      '                <th>role</th>\n' +
      '                <th>github</th>\n' +
      '              </tr>\n' +
      '            </thead>\n' +
      '            <tbody>\n' +
      rows +
      '            </tbody>\n' +
      '          </table>\n' +
      '        </div>\n' +
      '      </div>\n' +
      '    </main>\n\n' +
      '    <footer class="footer">\n' +
      '      <div class="footer-inner">\n' +
      '        <span>/home/OSC-MUST</span>\n' +
      '        <span>Misr University for Science and Technology</span>\n' +
      '      </div>\n' +
      '    </footer>\n\n' +
      '  </div>\n' +
      '  <script src="app.js"><\/script>\n' +
      '</body>\n' +
      '</html>\n' +
      '<!-- Written by ELBULBOL -->\n';
  }

  function generateJoinHTML() {
    var links = '';
    state.siteData.join.links.forEach(function (lnk) {
      links += '          <a href="' + escHtml(lnk.url) + '" target="_blank" rel="noopener noreferrer" class="link-row">\n' +
        '            <span class="tag">[&nbsp;' + escHtml(lnk.label) + '&nbsp;]</span>\n' +
        '            <span class="url">' + escHtml(lnk.url) + '</span>\n' +
        '            <span>→</span>\n' +
        '          </a>\n';
    });

    return '<!DOCTYPE html>\n' +
      '<html lang="en" dir="ltr">\n' +
      '<head>\n' +
      '  <meta charset="UTF-8" />\n' +
      '  <meta name="viewport" content="width=device-width, initial-scale=1.0" />\n' +
      '  <link rel="icon" type="image/png" href="assets/OSC_logo-psd.png" />\n' +
      '  <title>Join — OSC-MUST</title>\n' +
      '  <link rel="preconnect" href="https://fonts.googleapis.com" />\n' +
      '  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />\n' +
      '  <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet" />\n' +
      '  <link rel="stylesheet" href="style.css" />\n' +
      '</head>\n' +
      '<body>\n' +
      '  <div class="site-wrapper">\n\n' +
      '    <nav class="nav">\n' +
      '      <div class="nav-inner">\n' +
      '        <div class="nav-left">\n' +
      '          <a href="index.html" class="nav-prompt">\n' +
      '            <span class="bracket">[</span>user@osc-must ~<span class="bracket">]$</span>\n' +
      '          </a>\n' +
      '          <div class="nav-links">\n' +
      '            <a href="about.html"  class="nav-link">./about</a>\n' +
      '            <a href="blog.html"   class="nav-link">./blog</a>\n' +
      '            <a href="events.html" class="nav-link">./events</a>\n' +
      '            <a href="team.html"   class="nav-link">./team</a>\n' +
      '            <a href="join.html"   class="nav-link active">./join</a>\n' +
      '          </div>\n' +
      '        </div>\n' +
      '      </div>\n' +
      '    </nav>\n\n' +
      '    <main>\n' +
      '      <div class="container-narrow py-12">\n' +
      '        <p class="page-header">[user@osc-must ~]$ cat join.txt</p>\n\n' +
      '        <p style="font-size:0.875rem; line-height:1.75; color:var(--fg); margin-bottom:2rem; max-width:65ch;">\n' +
      '          ' + escHtml(state.siteData.join.text) + '\n' +
      '        </p>\n\n' +
      '        <div class="link-list">\n' +
      links +
      '        </div>\n' +
      '      </div>\n' +
      '    </main>\n\n' +
      '    <footer class="footer">\n' +
      '      <div class="footer-inner">\n' +
      '        <span>/home/OSC-MUST</span>\n' +
      '        <span>Misr University for Science and Technology</span>\n' +
      '      </div>\n' +
      '    </footer>\n\n' +
      '  </div>\n' +
      '  <script src="app.js"><\/script>\n' +
      '</body>\n' +
      '</html>\n' +
      '<!-- Written by ELBULBOL -->\n';
  }

  function generateIndexHTML() {
    var evRows = '';
    state.siteData.events.forEach(function (ev) {
      evRows += '              <tr>\n' +
        '                <td class="c-muted">' + escHtml(ev.perms) + '</td>\n' +
        '                <td class="c-accent">' + escHtml(ev.type) + '</td>\n' +
        '                <td class="c-muted">' + escHtml(ev.date) + '</td>\n' +
        '                <td><a href="events/' + escHtml(ev.filename) + '.html" class="c-primary">' + escHtml(ev.filename) + '</a></td>\n' +
        '                <td class="c-fg">' + escHtml(ev.title) + '</td>\n' +
        '              </tr>\n';
    });
    var blogRows = '';
    state.siteData.blog.forEach(function (b) {
      blogRows += '              <tr>\n' +
        '                <td class="c-muted">' + escHtml(b.perms) + '</td>\n' +
        '                <td class="c-muted">' + escHtml(b.date) + '</td>\n' +
        '                <td><a href="blog/' + escHtml(b.filename) + '.html" class="c-primary">' + escHtml(b.filename) + '.md</a></td>\n' +
        '                <td class="c-fg">' + escHtml(b.title) + '</td>\n' +
        '              </tr>\n';
    });
    var joinLinks = '';
    state.siteData.join.links.forEach(function (lnk) {
      joinLinks += '          <a href="' + escHtml(lnk.url) + '" target="_blank" rel="noopener noreferrer" class="link-row">\n' +
        '            <span class="tag">[&nbsp;' + escHtml(lnk.label) + '&nbsp;]</span>\n' +
        '            <span class="url">' + escHtml(lnk.url) + '</span>\n' +
        '            <span>→</span>\n' +
        '          </a>\n';
    });

    return '<!DOCTYPE html>\n' +
      '<html lang="en" dir="ltr">\n' +
      '<head>\n' +
      '  <meta charset="UTF-8" />\n' +
      '  <meta name="viewport" content="width=device-width, initial-scale=1.0" />\n' +
      '  <link rel="icon" type="image/png" href="assets/OSC_logo-psd.png" />\n' +
      '  <title>OSC-MUST — Open Source Community</title>\n' +
      '  <link rel="preconnect" href="https://fonts.googleapis.com" />\n' +
      '  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />\n' +
      '  <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet" />\n' +
      '  <link href="https://raw.githubusercontent.com/ryanoasis/nerd-fonts/master/patched-fonts/JetBrainsMono/Bold/JetBrainsMonoNerdFont-Bold.woff2" rel="preload" as="font" type="font/woff2" crossorigin />\n' +
      '  <style>\n' +
      '    @font-face {\n' +
      '      font-family: \'JetBrainsMono Nerd Font\';\n' +
      '      src: url(\'https://cdn.jsdelivr.net/npm/@fontsource/jetbrains-mono@4.5.0/index.min.css\');\n' +
      '      font-weight: 400;\n' +
      '    }\n' +
      '  </style>\n' +
      '  <link rel="stylesheet" href="style.css" />\n' +
      '</head>\n' +
      '<body>\n' +
      '  <div class="site-wrapper">\n\n' +
      '    <nav class="nav">\n' +
      '      <div class="nav-inner">\n' +
      '        <div class="nav-left">\n' +
      '          <a href="index.html" class="nav-prompt">\n' +
      '            <span class="bracket">[</span>user@osc-must ~<span class="bracket">]$</span>\n' +
      '          </a>\n' +
      '          <div class="nav-links">\n' +
      '            <a href="about.html"  class="nav-link">./about</a>\n' +
      '            <a href="blog.html"   class="nav-link">./blog</a>\n' +
      '            <a href="events.html" class="nav-link">./events</a>\n' +
      '            <a href="team.html"   class="nav-link">./team</a>\n' +
      '            <a href="join.html"   class="nav-link">./join</a>\n' +
      '          </div>\n' +
      '        </div>\n' +
      '      </div>\n' +
      '    </nav>\n\n' +
      '    <main>\n\n' +
      '      <section class="hero">\n' +
      '        <div class="corner-ring top-left"></div>\n' +
      '        <div class="corner-ring top-right"></div>\n' +
      '        <div class="corner-ring bottom-left"></div>\n' +
      '        <div class="corner-ring bottom-right"></div>\n\n' +
      '        <div class="logo-wrap">\n' +
      '          <img src="assets/OSC_logo-psd.png" alt="OSC-MUST Logo" class="site-logo" />\n' +
      '        </div>\n\n' +
      '        <h1 class="hero-title">MUST Open Source Community</h1>\n' +
      '        <p class="hero-subtitle">/home/OSC-MUST</p>\n\n' +
      '        <div class="hero-typing">\n' +
      '          <span class="typing-text" id="typing-text"></span>\n' +
      '          <span class="cursor-blink">▌</span>\n' +
      '        </div>\n\n' +
      '        <div class="scroll-hint">↓</div>\n' +
      '      </section>\n\n' +
      '      <section class="section container reveal">\n' +
      '        <p class="section-header">[user@osc-must ~]$ ls -la ./events/</p>\n' +
      '        <div class="table-wrap">\n' +
      '          <table class="terminal-table">\n' +
      '            <thead>\n' +
      '              <tr>\n' +
      '                <th>perms</th>\n' +
      '                <th>type</th>\n' +
      '                <th>date</th>\n' +
      '                <th>filename</th>\n' +
      '                <th>description</th>\n' +
      '              </tr>\n' +
      '            </thead>\n' +
      '            <tbody>\n' +
      evRows +
      '            </tbody>\n' +
      '          </table>\n' +
      '        </div>\n' +
      '      </section>\n\n' +
      '      <section class="section container reveal">\n' +
      '        <p class="section-header">[user@osc-must ~]$ ls -la ./blog/</p>\n' +
      '        <div class="table-wrap">\n' +
      '          <table class="terminal-table">\n' +
      '            <thead>\n' +
      '              <tr>\n' +
      '                <th>perms</th>\n' +
      '                <th>date</th>\n' +
      '                <th>filename</th>\n' +
      '                <th>title</th>\n' +
      '              </tr>\n' +
      '            </thead>\n' +
      '            <tbody>\n' +
      blogRows +
      '            </tbody>\n' +
      '          </table>\n' +
      '        </div>\n' +
      '      </section>\n\n' +
      '      <section class="section container reveal">\n' +
      '        <h2 class="section-title">Join Us</h2>\n' +
      '        <div class="link-list">\n' +
      joinLinks +
      '        </div>\n' +
      '      </section>\n\n' +
      '    </main>\n\n' +
      '    <footer class="footer">\n' +
      '      <div class="footer-inner">\n' +
      '        <span>/home/OSC-MUST</span>\n' +
      '        <span>Misr University for Science and Technology</span>\n' +
      '      </div>\n' +
      '    </footer>\n\n' +
      '  </div>\n\n' +
      '  <script src="app.js"><\/script>\n' +
      '</body>\n' +
      '</html>\n' +
      '<!-- Written by ELBULBOL -->\n';
  }

  function escHtml(str) {
    if (!str) return '';
    return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function slugify(str) {
    return str.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  }

  function log(msg, type) {
    var logEl = $('publish-log');
    if (!logEl) return;
    show(logEl);
    var line = el('div', { className: 'log-line' + (type === 'error' ? ' log-error' : type === 'success' ? ' log-success' : '') },
      '$ ' + msg
    );
    logEl.appendChild(line);
    logEl.scrollTop = logEl.scrollHeight;
  }

  function addChange(filepath, content, action) {
    state.pendingChanges[filepath] = { content: content, action: action || 'update' };
    updateChangesCount();
  }

  function updateChangesCount() {
    var count = Object.keys(state.pendingChanges).length;
    $('changes-count').textContent = count;
    $('publish-btn').disabled = count === 0;
  }

  function renderAll() {
    renderAbout();
    renderBlog();
    renderEvents();
    renderTeam();
    renderJoin();
  }

  function renderAbout() {
    $('about-text').value = state.siteData.about.paragraphs.join('\n\n');
    renderAboutTags();
  }

  function renderAboutTags() {
    var container = $('about-tags');
    container.innerHTML = '';
    state.siteData.about.tags.forEach(function (tag, idx) {
      var tagEl = el('div', { className: 'admin-tag-item' }, [
        el('span', { className: 'tag' }, tag),
        el('button', {
          className: 'admin-btn-icon admin-btn-danger',
          onClick: function () {
            state.siteData.about.tags.splice(idx, 1);
            renderAboutTags();
            stageAboutChanges();
          }
        }, '✕')
      ]);
      container.appendChild(tagEl);
    });
  }

  function renderBlog() {
    var container = $('blog-list');
    container.innerHTML = '';
    state.siteData.blog.forEach(function (post, idx) {
      var row = el('div', { className: 'admin-item-row' }, [
        el('span', { className: 'c-muted' }, post.perms),
        el('span', { className: 'c-muted' }, post.date),
        el('span', { className: 'c-primary' }, post.filename + '.md'),
        el('span', { className: 'c-fg' }, post.title),
        el('button', {
          className: 'admin-btn-icon admin-btn-danger',
          onClick: function () {
            if (confirm('Delete blog post "' + post.filename + '"?')) {
              addChange('blog/' + post.filename + '.html', null, 'delete');
              state.siteData.blog.splice(idx, 1);
              renderBlog();
              stageBlogListChanges();
            }
          }
        }, 'rm')
      ]);
      container.appendChild(row);
    });
  }

  function renderEvents() {
    var container = $('events-list');
    container.innerHTML = '';
    state.siteData.events.forEach(function (ev, idx) {
      var row = el('div', { className: 'admin-item-row' }, [
        el('span', { className: 'c-muted' }, ev.perms),
        el('span', { className: 'c-accent' }, ev.type),
        el('span', { className: 'c-muted' }, ev.date),
        el('span', { className: 'c-primary' }, ev.filename),
        el('span', { className: 'c-fg' }, ev.title),
        el('button', {
          className: 'admin-btn-icon admin-btn-danger',
          onClick: function () {
            if (confirm('Delete event "' + ev.filename + '"?')) {
              addChange('events/' + ev.filename + '.html', null, 'delete');
              state.siteData.events.splice(idx, 1);
              renderEvents();
              stageEventsListChanges();
            }
          }
        }, 'rm')
      ]);
      container.appendChild(row);
    });
  }

  function renderTeam() {
    var container = $('team-list');
    container.innerHTML = '';
    state.siteData.team.forEach(function (member, idx) {
      var row = el('div', { className: 'admin-item-row admin-team-row' }, [
        el('div', { className: 'admin-team-fields' }, [
          el('div', { className: 'admin-team-field' }, [
            el('label', { className: 'admin-sublabel' }, 'Handle:'),
            el('input', {
              className: 'admin-input admin-input-sm',
              type: 'text',
              value: member.handle,
              onChange: function (e) {
                state.siteData.team[idx].handle = e.target.value;
                stageTeamChanges();
              }
            })
          ]),
          el('div', { className: 'admin-team-field' }, [
            el('label', { className: 'admin-sublabel' }, 'Role:'),
            el('input', {
              className: 'admin-input admin-input-sm',
              type: 'text',
              value: member.role,
              onChange: function (e) {
                state.siteData.team[idx].role = e.target.value;
                stageTeamChanges();
              }
            })
          ]),
          el('div', { className: 'admin-team-field' }, [
            el('label', { className: 'admin-sublabel' }, 'GitHub:'),
            el('input', {
              className: 'admin-input admin-input-sm',
              type: 'text',
              value: member.github,
              onChange: function (e) {
                state.siteData.team[idx].github = e.target.value;
                stageTeamChanges();
              }
            })
          ])
        ]),
        el('button', {
          className: 'admin-btn-icon admin-btn-danger',
          onClick: function () {
            if (confirm('Remove team member "' + member.handle + '"?')) {
              state.siteData.team.splice(idx, 1);
              renderTeam();
              stageTeamChanges();
            }
          }
        }, 'userdel')
      ]);
      container.appendChild(row);
    });
  }

  function renderJoin() {
    $('join-text').value = state.siteData.join.text;
    renderJoinLinks();
  }

  function renderJoinLinks() {
    var container = $('join-links');
    container.innerHTML = '';
    state.siteData.join.links.forEach(function (link, idx) {
      var row = el('div', { className: 'admin-item-row' }, [
        el('span', { className: 'tag' }, '[' + link.label + ']'),
        el('input', {
          className: 'admin-input admin-input-sm',
          type: 'text',
          value: link.url,
          onChange: function (e) {
            state.siteData.join.links[idx].url = e.target.value;
            stageJoinChanges();
          }
        }),
        el('button', {
          className: 'admin-btn-icon admin-btn-danger',
          onClick: function () {
            state.siteData.join.links.splice(idx, 1);
            renderJoinLinks();
            stageJoinChanges();
          }
        }, 'rm')
      ]);
      container.appendChild(row);
    });
  }

  function stageAboutChanges() {
    addChange('about.html', generateAboutHTML(), 'update');
  }

  function stageBlogListChanges() {
    addChange('blog.html', generateBlogListHTML(), 'update');
    addChange('index.html', generateIndexHTML(), 'update');
  }

  function stageEventsListChanges() {
    addChange('events.html', generateEventsListHTML(), 'update');
    addChange('index.html', generateIndexHTML(), 'update');
  }

  function stageTeamChanges() {
    addChange('team.html', generateTeamHTML(), 'update');
  }

  function stageJoinChanges() {
    addChange('join.html', generateJoinHTML(), 'update');
    addChange('index.html', generateIndexHTML(), 'update');
  }

  /* ── Publish: save all files locally, then git add+commit+push ─ */
  function publishAll() {
    var changes = Object.keys(state.pendingChanges);
    if (changes.length === 0) return;

    var commitMsg = $('commit-message').value || 'Update site content via admin panel';
    $('publish-btn').disabled = true;
    $('publish-btn').textContent = '⏳ saving files...';
    $('publish-log').innerHTML = '';
    show($('publish-log'));

    log('Saving ' + changes.length + ' file(s) to disk...');

    // Step 1: Save/delete each file via local server API
    var chain = Promise.resolve();
    changes.forEach(function (filepath) {
      chain = chain.then(function () {
        var change = state.pendingChanges[filepath];
        if (change.action === 'delete') {
          log('rm ' + filepath);
          return api('POST', '/api/file/delete', { path: filepath }).then(function (r) {
            if (r.error) { log('ERROR: ' + r.error, 'error'); throw new Error(r.error); }
            log(filepath + ' deleted ✓', 'success');
          });
        } else {
          log('writing ' + filepath);
          return api('POST', '/api/file/save', { path: filepath, content: change.content }).then(function (r) {
            if (r.error) { log('ERROR: ' + r.error, 'error'); throw new Error(r.error); }
            log(filepath + ' saved ✓', 'success');
          });
        }
      });
    });

    // Step 2: git add . && git commit && git push
    chain.then(function () {
      log('');
      log('All files saved. Running git push...');
      $('publish-btn').textContent = '⏳ git push...';
      return api('POST', '/api/git/push', { message: commitMsg });
    }).then(function (r) {
      if (r.log) r.log.forEach(function (l) { log(l); });
      if (r.error) {
        log('Push failed: ' + r.error, 'error');
        $('publish-btn').textContent = '$ git add . && git commit && git push';
        $('publish-btn').disabled = false;
        return;
      }
      if (r.pushed) {
        log('');
        log('All changes pushed to GitHub! 🎉', 'success');
      } else {
        log(r.message || 'No changes to push.', 'success');
      }
      state.pendingChanges = {};
      updateChangesCount();
      $('publish-btn').textContent = '$ git add . && git commit && git push';
    }).catch(function (err) {
      log('Error: ' + err.message, 'error');
      $('publish-btn').textContent = '$ git add . && git commit && git push';
      $('publish-btn').disabled = false;
    });
  }

  /* ── Event Bindings ──────────────────────────────────────────── */
  function init() {
    // Load git user info and display it
    api('GET', '/api/git/user').then(function (r) {
      state.gitUser = r;
      $('git-username').textContent = r.name || 'unknown';
      $('git-remote').textContent = r.remote || 'not configured';
    }).catch(function () {
      $('git-username').textContent = 'error — is server.py running?';
    });

    // Tab switching
    document.querySelectorAll('.admin-tab').forEach(function (tab) {
      tab.addEventListener('click', function () {
        document.querySelectorAll('.admin-tab').forEach(function (t) { t.classList.remove('active'); });
        document.querySelectorAll('.admin-tab-content').forEach(function (c) { c.classList.remove('active'); });
        tab.classList.add('active');
        $(tab.dataset.tab).classList.add('active');
      });
    });

    // About: text change
    $('about-text').addEventListener('input', function () {
      state.siteData.about.paragraphs = this.value.split(/\n\s*\n/).filter(Boolean);
      stageAboutChanges();
    });

    // About: add tag
    $('about-add-tag').addEventListener('click', function () {
      var val = $('about-new-tag').value.trim();
      if (val) {
        state.siteData.about.tags.push(val);
        $('about-new-tag').value = '';
        renderAboutTags();
        stageAboutChanges();
      }
    });

    // Blog: add new post
    $('blog-add').addEventListener('click', function () {
      var filename = slugify($('blog-filename').value) || slugify($('blog-title').value);
      var title = $('blog-title').value.trim();
      var date = $('blog-date').value;
      var perms = $('blog-perms').value || '-rw-r--r--';
      var content = $('blog-content').value.trim();

      if (!filename || !title || !date) {
        alert('Please fill in filename, title, and date.');
        return;
      }

      var post = { filename: filename, title: title, date: date, perms: perms, content: content };
      state.siteData.blog.unshift(post);
      renderBlog();

      addChange('blog/' + filename + '.html', generateBlogPostHTML(post), 'create');
      stageBlogListChanges();

      $('blog-filename').value = '';
      $('blog-title').value = '';
      $('blog-date').value = '';
      $('blog-content').value = '';

      log('Staged new blog post: ' + filename);
    });

    // Events: add new event
    $('event-add').addEventListener('click', function () {
      var filename = slugify($('event-filename').value) || slugify($('event-title').value);
      var title = $('event-title').value.trim();
      var date = $('event-date').value;
      var type = $('event-type').value.trim() || 'workshop';
      var perms = $('event-perms').value || 'drwxr-xr-x';
      var location = $('event-location').value.trim();
      var content = $('event-content').value.trim();

      if (!filename || !title || !date) {
        alert('Please fill in filename, title, and date.');
        return;
      }

      var ev = { filename: filename, title: title, date: date, type: type, perms: perms, location: location, content: content };
      state.siteData.events.push(ev);
      renderEvents();

      addChange('events/' + filename + '.html', generateEventPageHTML(ev), 'create');
      stageEventsListChanges();

      $('event-filename').value = '';
      $('event-title').value = '';
      $('event-date').value = '';
      $('event-content').value = '';
      $('event-location').value = '';

      log('Staged new event: ' + filename);
    });

    // Team: add member
    $('team-add').addEventListener('click', function () {
      var handle = $('team-handle').value.trim();
      var role = $('team-role').value.trim();
      var github = $('team-github').value.trim();

      if (!handle || !role) {
        alert('Please fill in handle and role.');
        return;
      }

      state.siteData.team.push({ handle: handle, role: role, github: github });
      renderTeam();
      stageTeamChanges();

      $('team-handle').value = '';
      $('team-role').value = '';
      $('team-github').value = '';

      log('Staged new team member: ' + handle);
    });

    // Join: text change
    $('join-text').addEventListener('input', function () {
      state.siteData.join.text = this.value.trim();
      stageJoinChanges();
    });

    // Join: add link
    $('join-add-link').addEventListener('click', function () {
      var label = $('join-link-label').value.trim();
      var url = $('join-link-url').value.trim();

      if (!label || !url) {
        alert('Please fill in label and URL.');
        return;
      }

      state.siteData.join.links.push({ label: label, url: url });
      renderJoinLinks();
      stageJoinChanges();

      $('join-link-label').value = '';
      $('join-link-url').value = '';

      log('Staged new link: [' + label + ']');
    });

    // Publish button
    $('publish-btn').addEventListener('click', publishAll);

    // Load site data immediately (no auth needed!)
    loadSiteData();
  }

  // Boot
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
