#!/usr/bin/env python3
"""
OSC-MUST Admin Server
A tiny local server that:
  1. Serves the entire repo as static files
  2. Provides API endpoints to read/write files and run git commands
  3. Uses YOUR local git config (SSH keys / HTTPS credentials) — no tokens needed

Usage:
  cd /path/to/OSC-MUST-main
  python3 admin/server.py

Then open: http://localhost:8001/admin/
"""

import http.server
import json
import os
import subprocess
import urllib.parse

PORT = 8001
# Repo root is one level above admin/
REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class AdminHandler(http.server.SimpleHTTPRequestHandler):
    """Extend SimpleHTTPRequestHandler with API routes."""

    def __init__(self, *args, **kwargs):
        # Serve files from repo root so all paths (../style.css etc.) resolve
        super().__init__(*args, directory=REPO_ROOT, **kwargs)

    def end_headers(self):
        # Disable caching for development
        self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
        self.send_header('Pragma', 'no-cache')
        self.send_header('Expires', '0')
        super().end_headers()

    # Override to prevent 304 responses during development
    def send_header(self, keyword, value):
        # Suppress Last-Modified so browser can't send If-Modified-Since
        if keyword.lower() == 'last-modified':
            return
        super().send_header(keyword, value)

    # ── Routing ────────────────────────────────────────────────
    def do_GET(self):
        # Strip conditional headers so the server never returns 304
        if 'If-Modified-Since' in self.headers:
            del self.headers['If-Modified-Since']
        if 'If-None-Match' in self.headers:
            del self.headers['If-None-Match']

        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        if path == '/api/files':
            self._api_list_files(parsed)
        elif path == '/api/read':
            # Alternative read route — avoids 'index.html' in URL path
            qs = urllib.parse.parse_qs(parsed.query)
            filepath = qs.get('path', [''])[0]
            if filepath:
                self._api_read_file(filepath)
            else:
                self._json_response(400, {'error': 'Missing "path" query param'})
        elif path.startswith('/api/file/'):
            self._api_read_file(path[len('/api/file/'):])
        elif path == '/api/git/status':
            self._api_git_status()
        elif path == '/api/git/user':
            self._api_git_user()
        else:
            super().do_GET()

    def do_POST(self):
        path = urllib.parse.urlparse(self.path).path

        if path == '/api/file/save':
            self._api_save_file()
        elif path == '/api/file/delete':
            self._api_delete_file()
        elif path == '/api/git/push':
            self._api_git_push()
        else:
            self._json_response(404, {'error': 'Not found'})

    # ── API: Read files ────────────────────────────────────────
    def _api_list_files(self, parsed):
        """List files matching a pattern (query param: dir=blog)"""
        qs = urllib.parse.parse_qs(parsed.query)
        subdir = qs.get('dir', [''])[0]
        target = os.path.join(REPO_ROOT, subdir)
        if not os.path.isdir(target):
            self._json_response(404, {'error': 'Directory not found'})
            return
        files = []
        for f in sorted(os.listdir(target)):
            fp = os.path.join(target, f)
            if os.path.isfile(fp):
                files.append(f)
        self._json_response(200, {'dir': subdir, 'files': files})

    def _api_read_file(self, filepath):
        """Read a file's content. Path is relative to repo root."""
        filepath = urllib.parse.unquote(filepath)
        full = os.path.join(REPO_ROOT, filepath)
        if not os.path.isfile(full):
            self._json_response(404, {'error': 'File not found: ' + filepath})
            return
        try:
            with open(full, 'r', encoding='utf-8') as f:
                content = f.read()
            self._json_response(200, {'path': filepath, 'content': content})
        except Exception as e:
            self._json_response(500, {'error': str(e)})

    # ── API: Write / Delete files ──────────────────────────────
    def _api_save_file(self):
        """Save content to a file (creates directories if needed)."""
        data = self._read_json_body()
        if not data:
            return
        filepath = data.get('path', '')
        content = data.get('content', '')
        if not filepath:
            self._json_response(400, {'error': 'Missing "path"'})
            return

        full = os.path.join(REPO_ROOT, filepath)
        try:
            os.makedirs(os.path.dirname(full), exist_ok=True)
            with open(full, 'w', encoding='utf-8') as f:
                f.write(content)
            self._json_response(200, {'saved': filepath})
        except Exception as e:
            self._json_response(500, {'error': str(e)})

    def _api_delete_file(self):
        """Delete a file."""
        data = self._read_json_body()
        if not data:
            return
        filepath = data.get('path', '')
        if not filepath:
            self._json_response(400, {'error': 'Missing "path"'})
            return

        full = os.path.join(REPO_ROOT, filepath)
        if not os.path.isfile(full):
            self._json_response(404, {'error': 'File not found: ' + filepath})
            return
        try:
            os.remove(full)
            self._json_response(200, {'deleted': filepath})
        except Exception as e:
            self._json_response(500, {'error': str(e)})

    # ── API: Git operations ────────────────────────────────────
    def _api_git_status(self):
        """Return git status."""
        result = self._run_git('status', '--porcelain')
        if result is None:
            return
        changed = [l.strip() for l in result.stdout.strip().split('\n') if l.strip()]
        self._json_response(200, {'changed': changed, 'clean': len(changed) == 0})

    def _api_git_user(self):
        """Return the configured git user."""
        name_r = self._run_git('config', 'user.name')
        email_r = self._run_git('config', 'user.email')
        remote_r = self._run_git('remote', 'get-url', 'origin')
        self._json_response(200, {
            'name': name_r.stdout.strip() if name_r else '',
            'email': email_r.stdout.strip() if email_r else '',
            'remote': remote_r.stdout.strip() if remote_r else ''
        })

    def _api_git_push(self):
        """git add . && git commit -m "..." && git push"""
        data = self._read_json_body()
        if not data:
            return
        message = data.get('message', 'Update site content via admin panel')

        log = []

        # git add .
        r = self._run_git('add', '.')
        if r is None:
            return
        log.append('$ git add .')
        if r.returncode != 0:
            log.append('ERROR: ' + r.stderr)
            self._json_response(500, {'log': log, 'error': 'git add failed'})
            return
        log.append('OK')

        # git commit
        r = self._run_git('commit', '-m', message)
        log.append('$ git commit -m "' + message + '"')
        if r.returncode != 0:
            stderr = r.stderr.strip()
            stdout = r.stdout.strip()
            if 'nothing to commit' in stdout or 'nothing to commit' in stderr:
                log.append('Nothing to commit (working tree clean)')
                self._json_response(200, {'log': log, 'pushed': False, 'message': 'Nothing to commit'})
                return
            log.append('ERROR: ' + stderr)
            self._json_response(500, {'log': log, 'error': 'git commit failed'})
            return
        log.append(r.stdout.strip())

        # git push
        r = self._run_git('push')
        log.append('$ git push')
        if r.returncode != 0:
            stderr = r.stderr.strip()
            # git push writes progress to stderr even on success
            if 'rejected' in stderr or 'error' in stderr.lower() or 'fatal' in stderr.lower():
                log.append('ERROR: ' + stderr)
                self._json_response(500, {'log': log, 'error': 'git push failed'})
                return
        # stderr may contain normal push output
        push_output = (r.stdout.strip() + '\n' + r.stderr.strip()).strip()
        log.append(push_output if push_output else 'OK')

        self._json_response(200, {'log': log, 'pushed': True})

    # ── Helpers ────────────────────────────────────────────────
    def _run_git(self, *args):
        try:
            result = subprocess.run(
                ['git'] + list(args),
                cwd=REPO_ROOT,
                capture_output=True,
                text=True,
                timeout=30
            )
            return result
        except Exception as e:
            self._json_response(500, {'error': 'git error: ' + str(e)})
            return None

    def _read_json_body(self):
        try:
            length = int(self.headers.get('Content-Length', 0))
            body = self.rfile.read(length)
            return json.loads(body)
        except Exception as e:
            self._json_response(400, {'error': 'Invalid JSON: ' + str(e)})
            return None

    def _json_response(self, code, data):
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps(data).encode('utf-8'))

    def log_message(self, format, *args):
        # Colorize API requests vs static files
        msg = format % args
        if '/api/' in msg:
            print(f'\033[36m[API]\033[0m {msg}')
        else:
            print(f'[SRV] {msg}')


def main():
    os.chdir(REPO_ROOT)
    print(f'\033[1m╔══════════════════════════════════════════╗\033[0m')
    print(f'\033[1m║   OSC-MUST Admin Server                  ║\033[0m')
    print(f'\033[1m╠══════════════════════════════════════════╣\033[0m')
    print(f'\033[1m║\033[0m  Repo:   {REPO_ROOT}')
    print(f'\033[1m║\033[0m  Admin:  \033[4mhttp://localhost:{PORT}/admin/\033[0m')
    print(f'\033[1m║\033[0m  Site:   \033[4mhttp://localhost:{PORT}/\033[0m')
    print(f'\033[1m║\033[0m  Auth:   Using local git config (SSH/HTTPS)')
    print(f'\033[1m╚══════════════════════════════════════════╝\033[0m')
    print()

    server = http.server.ThreadingHTTPServer(('0.0.0.0', PORT), AdminHandler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print('\nServer stopped.')
        server.server_close()


if __name__ == '__main__':
    main()
